let truck;
let bucket;
let milkAvailable = false;
let milkTimer = 0;
let score = 0;

function setup() {
  createCanvas(800, 400);
  truck = createVector(50, height - 80);
  bucket = createVector(400, height - 70);
  textSize(20);
}

function draw() {
  background(220);

  drawScene();

  // Mostrar balde de leite
  if (milkAvailable) {
    fill(255);
    ellipse(bucket.x, bucket.y, 30); // leite no balde
    fill(0);
    text("Leite pronto!", bucket.x - 40, bucket.y - 40);
  }

  // Desenhar caminhão
  fill(0, 0, 255);
  rect(truck.x, truck.y, 60, 30);
  fill(255);
  text("Caminhão", truck.x, truck.y - 10);

  // Movimento do caminhão
  moveTruck();

  // Verifica coleta
  if (milkAvailable && dist(truck.x, truck.y, bucket.x, bucket.y) < 50) {
    milkAvailable = false;
    score++;
  }

  // Temporizador para novo leite
  milkTimer++;
  if (milkTimer > 180) { // a cada 3 segundos
    milkAvailable = true;
    milkTimer = 0;
  }

  // Pontuação
  fill(0);
  text("Leite Coletado: " + score, 20, 30);
}

function drawScene() {
  // Grama
  fill(100, 200, 100);
  rect(0, height - 50, width, 50);

  // Vaca (simples)
  fill(150);
  rect(bucket.x - 40, bucket.y - 70, 40, 30); // corpo
  fill(0);
  ellipse(bucket.x - 30, bucket.y - 75, 10);  // cabeça

  // Balde
  fill(150);
  rect(bucket.x - 10, bucket.y - 10, 20, 20);
  text("Balde", bucket.x - 20, bucket.y + 25);
}

function moveTruck() {
  if (keyIsDown(LEFT_ARROW)) {
    truck.x -= 5;
  }
  if (keyIsDown(RIGHT_ARROW)) {
    truck.x += 5;
  }

  // Limites
  truck.x = constrain(truck.x, 0, width - 60);
}